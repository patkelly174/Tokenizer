My project is written in Python it only uses the Python standard library for Part A and B.
I used matplotlib for making the graph for the report.
You will need to download Python to run this project https://www.python.org/downloads/
To run the code navigate to the source directory where the code is and type in
"python3 tokenizer.py"
